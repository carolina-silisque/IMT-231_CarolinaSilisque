def dividir(a, b):
    return a / b