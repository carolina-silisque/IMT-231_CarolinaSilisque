from .suma import sumar
from .resta import restar
from .multiplicacion import multiplicar
from .division import dividir